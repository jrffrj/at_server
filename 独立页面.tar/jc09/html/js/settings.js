var menustatus = "";
var imei = "";
var swVersion = "";

function checkSettingsHtml(htmlName) {
    document.getElementById('settings_right').innerHTML = "";
    document.getElementById('settings_right').innerHTML = callProductHTML("html/setting_router.html");
}

function checkSettingMenuIcon(menuName) {
     if (menuName === menustatus) {
         switch (menuName) {
             case "setting_menu_firewall":
                 document.getElementById("firewall_child_menu").style.display = "none";
                 document.getElementById("img_menu_firewall").src = "../images/main/more_nav_arrow_down.png";
                 menustatus = ""
                 break;
         }
         return;
     }
    document.getElementById("setting_menu_imei").className = "settings_menu_normal";
    document.getElementById("setting_menu_at").className = "settings_menu_normal";
    document.getElementById("setting_menu_lock").className = "settings_menu_normal";
    document.getElementById("text_menu_imei").className = "settings_menu_text_normal";
    document.getElementById("text_menu_at").className = "settings_menu_text_normal";
    document.getElementById("text_menu_lock").className = "settings_menu_text_normal";
    if (menuName === "settings_menu_router") {
        document.getElementById(menuName).className = "settings_menu_select";
        document.getElementById("text_menu_router").className = "settings_menu_text_select";
        hideSettingRight();
        document.getElementById("settings_router").style.display = "block";
        stone_getXMLCfg("sysinfo", setRouterValue);
    } else if (menuName === "setting_menu_imei") {                                            
        document.getElementById(menuName).className = "settings_menu_select";                     
        document.getElementById("text_menu_imei").className = "settings_menu_text_select";  
        hideSettingRight();                                                                     
        document.getElementById("system_imei").style.display = "block";                     
    } else if (menuName === "setting_menu_at") {
        document.getElementById(menuName).className = "settings_menu_select";          
        document.getElementById("text_menu_at").className = "settings_menu_text_select";
        hideSettingRight();                                               
        document.getElementById("system_at").style.display = "block";  
    } else if (menuName === "setting_menu_lock") {                                              
        document.getElementById(menuName).className = "settings_menu_select";                 
        document.getElementById("text_menu_lock").className = "settings_menu_text_select";      
        hideSettingRight();
	getLOCK();                                                    
        document.getElementById("system_lock").style.display = "block";
    }
}
function hideSettingRight() {
    document.getElementById("system_imei").style.display = "none";
    document.getElementById("system_at").style.display = "none";
    document.getElementById("system_lock").style.display = "none";
}

function detectVersion() {
    stone_getXMLCfg("checkNewVersion", getUploadValue);
}


function lockinfo(content){
    var data = content;
            document.getElementById("now_earfcn").innerHTML = $(data).find("earfcn").text();
            document.getElementById("now_rsrp").innerHTML = $(data).find("rsrp").text() + " dBm";
            document.getElementById("now_pci").innerHTML = $(data).find("pci").text();
}

function setIMEI() {                                                                                                                                                                                                                                                                 
    var imei = $('#setting_imei').val();                                                                                                                                                                                                         
    if ($.trim(imei) === "") {                                                          
        alert("不能为空"); 
        return;                                                                           
    }                                                                                 
                                                                                               
    if (imei.indexOf(" ") !== -1) {                                                       
        alert("不能有空格");
        return false;                                                                 
    }
    if (!isNumber(imei)) {                                                                      
        alert("必须全是数字");
        return false;                                                                             
    }                                                                                         
    if (imei.length!=15) {
        alert("长度必须为15");   
        return false;                                                        
    }                                                                                                                                                                                                                                                                                         
        var url = LOCAL_HOST_IP + "quickSetUser";      
	var param = {imei:imei}
        $.ajax({                                                                                                                                                                                                                                                                            
            url: "/api/imei",                                                                                                                                                                                                                                                                       
            dataType: "json", 
	    type:"POST",                                                                                                                                                                                                                                                             
            data: JSON.stringify(param),                                                                                                                                                                                                                
            success: function (data) {                                                                                                                                                                                                                                                      
                console.log("data = ", data);                                                                                                                                                                                                                                               
                var state = data.state;                                                                                                                                                                                                                                                     
                console.log("state " + state);                                                                                                                                                                                                                                              
                if (state === 1) {                                                                                                                                                                                                                                                          
                    alert("设置成功");
		    alert("需重启设备后生效");
		    window.location.reload();                                                                                                                                                                                                                                                         
                } else {                                                                                                                                                                                                                                                                        
                    alert("设置失败");                                                                                                                                                                                                                                          
                }                                                                                                                                                                                                                                                                           
            }                                                                                                                                                                                                                                                                               
        });//.responseText;                                                                                                                                                                                                                                                                                    
}
function getLOCK() {
        $.ajax({
            url: "/api/lockr",
            dataType: "json",
            type:"GET",
            success: function (data) {
		var lockinfo = data.lock.split(',');
		console.log(lockinfo);
		if (lockinfo.length === 4){
			$("input[name='setting_type']:radio[value="+lockinfo[0]+"]").attr('checked','true');
                        $("#setting_earfcn").val(lockinfo[2]);
                        $("#setting_pci").val(lockinfo[3]);
		}
            }
        });
}
function setLOCK() {
    var type = $("input[name='setting_type']:checked").val();
    if(type!=0){
	lockinfo=$("input[name='setting_type']:checked").val()+",2,"+$.trim($("#setting_earfcn").val())+","+$.trim($("#setting_pci").val());
    }else{
        lockinfo="";
    }
        var param = {lock:lockinfo};
        $.ajax({
            url: "/api/lockw",
            dataType: "json",
            type:"POST",
            data: JSON.stringify(param),
            success: function (data) {
		if (data.state === 1) {                                                                                                                                                                                                                                                   
                    alert("设置成功");
                    window.location.reload();
                } else {                                                                                                                                                                                                                                                      
                    alert("设置失败");    
                    window.location.reload();
                }
            }                                                                                                
        }); 
	console.log(lockinfo);
}
function sendat() {
    var at = $('#setting_at').val(); 
    if ($.trim(at) === "") { 
        alert("不能为空"); 
        return; 
    } 
    if (imei.indexOf(" ") !== -1) {
        alert("不能有空格");
        return false;
    } 
        var param = {cmd:at}
        $.ajax({
            url: "/api/at",                  
            type:"POST",
            data: JSON.stringify(param),
            success: function (data) {
                console.log("data = ", data); 
                    $("#at_result").html(data);
            }
        });  
}