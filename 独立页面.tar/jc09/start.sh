#!/bin/sh
sleep 30
cd /home/root
./at_server &
